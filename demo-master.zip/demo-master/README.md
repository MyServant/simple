# demo
this is a demo.
this is a demo.
this is a demo.

To use cdn of jsdelivr.

https://cdn.jsdelivr.net/gh/IceSeclude/demo/src/script/simpleMemory.min.js


用法
https://blog.csdn.net/qq_36036735/article/details/110424864?utm_medium=distribute.pc_aggpage_search_result.none-task-blog-2~aggregatepage~first_rank_ecpm_v1~rank_v31_ecpm-1-110424864-null-null.pc_agg_new_rank&utm_term=jsDelivr%E6%80%8E%E4%B9%88%E4%BD%BF%E7%94%A8&spm=1000.2123.3001.4430
